#!/usr/bin/python
# -*- coding: utf-8 -*-
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program. If not, see <http://www.gnu.org/licenses/>.
#
#    This script is a modification of service.skin.widgets and service.library.data.provider
#    Thanks to the original authors: BigNoid, Unfledged and Martijn.

import os
import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import random
import urllib
import datetime
from traceback import print_exc
from time import gmtime, strftime

if sys.version_info < (2, 7):
    import simplejson
else:
    import json as simplejson

__addon__        = xbmcaddon.Addon()
__addonversion__ = __addon__.getAddonInfo('version')
__addonid__      = __addon__.getAddonInfo('id')
__addonname__    = __addon__.getAddonInfo('name')
__localize__     = __addon__.getLocalizedString

class Main:
    def __init__(self):
        self._parse_argv()
         # Play an album
        if self.TYPE == "open_album":
            xbmc.executebuiltin("Skin.Reset(showRecentMusicItems)")
            xbmc.executebuiltin("replacewindow(Music,musicdb://albums/%d)" % int(self.ALBUM))
            xbmc.executebuiltin("Control.SetFocus(56,1)")

        if self.TYPE == "open_tvshow":
            xbmc.executebuiltin("Skin.Reset(showRecentVideoItems)")
            xbmc.executebuiltin("replacewindow(Video,videodb://tvshows/titles/%d/%d)" % (int(self.TVSHOW),int(self.SEASON)))
            xbmc.executebuiltin("Control.SetFocus(52,1)")

        for type in self.TYPE.split( "+" ):
            full_liz = list()
            if self.TYPE == "recentmovies":
                xbmcplugin.setContent(int(sys.argv[1]),'movies')
                self.parse_movies('recentmovies',32005,full_liz)
                xbmcplugin.addDirectoryItems(int(sys.argv[1]),full_liz)
                xbmcplugin.endOfDirectory(handle=int(sys.argv[1]))
            elif self.TYPE == "randommovies":
                xbmcplugin.setContent(int(sys.argv[1]),'movies')
                self.parse_movies('randommovies',32004,full_liz)
                xbmcplugin.addDirectoryItems(int(sys.argv[1]),full_liz)
                xbmcplugin.endOfDirectory(handle=int(sys.argv[1]))
            elif self.TYPE == "recentepisodes":
                xbmcplugin.setContent(int(sys.argv[1]),'episodes')
                self.parse_tvshows('recentepisodes',32008,full_liz)
                xbmcplugin.addDirectoryItems(int(sys.argv[1]),full_liz)
                xbmcplugin.endOfDirectory(handle=int(sys.argv[1]))
            elif self.TYPE == "randomepisodes":
                xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
                self.parse_tvshows( 'randomepisodes', 32007, full_liz )
                xbmcplugin.addDirectoryItems(int(sys.argv[1]),full_liz)
                xbmcplugin.endOfDirectory(handle=int(sys.argv[1]))
            elif self.TYPE == "recentalbums":
                xbmcplugin.setContent(int(sys.argv[1]),'albums')
                self.parse_albums('recentalbums',32017,full_liz)
                xbmcplugin.addDirectoryItems(int(sys.argv[1]),full_liz)
                xbmcplugin.endOfDirectory(handle=int(sys.argv[1]))
            elif self.TYPE == "randomalbums":
                xbmcplugin.setContent(int(sys.argv[1]),'albums')
                self.parse_albums('randomalbums',32016,full_liz)
                xbmcplugin.addDirectoryItems(int(sys.argv[1]),full_liz)
                xbmcplugin.endOfDirectory(handle=int(sys.argv[1]))
            elif self.TYPE == "favouritealbums":
                xbmcplugin.setContent(int(sys.argv[1]),'albums')
                self.parse_albums('favouritealbums',32016,full_liz)
                xbmcplugin.addDirectoryItems(int(sys.argv[1]),full_liz)
                xbmcplugin.endOfDirectory(handle=int(sys.argv[1]))

    def parse_movies(self,request,list_type,full_liz):
        json_query = self._get_data(request)
        while json_query == "LOADING":
            xbmc.sleep(100)
            json_query = self._get_data(request)
        count = 0
        if json_query:
            json_query = simplejson.loads(json_query)
            if json_query.has_key('result') and json_query['result'].has_key('movies'):
                for item in json_query['result']['movies']:
                    # create a list item
                    liz = xbmcgui.ListItem(item['title'])
                    liz.setInfo( type="Video", infoLabels={ "Title": item['title'] })
                    liz.setInfo( type="Video", infoLabels={ "Year": item['year'] })
                    liz.setInfo( type="Video", infoLabels={ "Plot": item['plot'] })
                    liz.setInfo( type="Video", infoLabels={ "Genre": item['genre'][0] })
                    liz.setInfo( type="Video", infoLabels={ "MPAA": item['mpaa'] })
                    full_liz.append((item['file'], liz, False))
                    liz.setArt(item['art'])
                    liz.setThumbnailImage(item['art'].get('poster',''))
                    liz.setProperty("dbid", str(item['movieid']))
                    liz.setProperty("fanart_image", item['art'].get('fanart', ''))
                    count += 1
                    if count == self.LIMIT:
                        break
            del json_query

    def parse_tvshows(self,request,list_type,full_liz):
        json_query = self._get_data(request)
        while json_query == "LOADING":
            xbmc.sleep(100)
            json_query = self._get_data(request)
        if json_query:
            json_query = simplejson.loads(json_query)
            if json_query.has_key('result') and json_query['result'].has_key('episodes'):
                count = 0
                #group episodes by tvshow and season
                tvshowcount = 0
                tvshows = []
                for item in json_query['result']['episodes']:
                    tvshowExists = filter(lambda tvshow: tvshow['tvshowid'] == item["tvshowid"], tvshows)
                    if tvshowExists:
                        seasonExists = filter(lambda season: season['season'] == item["season"], tvshowExists)
                        if seasonExists:
                            seasonExists[0]['episodecount'] += 1
                        else:
                            tvshows.append({"file":item["file"],"art":item["art"],"title":item["title"],"tvshowid":item["tvshowid"],"showtitle":item["showtitle"],"season":item["season"],"episodecount":1})

                    else:
                        tvshows.append({"file":item["file"],"art":item["art"],"title":item["title"],"tvshowid":item["tvshowid"],"showtitle":item["showtitle"],"season":item["season"],"episodecount":1})
                    if len(tvshows) == 0:
                       tvshows.append({"file":item["file"],"art":item["art"],"title":item["title"],"tvshowid":item["tvshowid"],"showtitle":item["showtitle"],"season":item["season"],"episodecount":1})
                #create final listing
                for tvshow in tvshows:
                    liz = xbmcgui.ListItem(tvshow['showtitle'])
                    liz.setInfo( type="Video", infoLabels={ "Title": tvshow['title'] })
                    liz.setInfo( type="Video", infoLabels={ "TVshowTitle": tvshow['showtitle'] })
                    liz.setInfo( type="Video", infoLabels={ "Season": tvshow['season'] })
                    liz.setInfo( type="Video", infoLabels={ "Plot": item['plot'] })
                    liz.setProperty("episodecount", str(tvshow['episodecount']))
                    liz.setProperty("type", __localize__(list_type))
                    liz.setArt(tvshow['art'])
                    liz.setThumbnailImage(tvshow['art'].get('thumb',''))
                    liz.setProperty("fanart_image", tvshow['art'].get('tvshow.fanart',''))
                    liz.setProperty("season_poster", tvshow['art'].get('tvshow.poster',''))
                    # Path will call plugin again, with the album id
                    path = sys.argv[0] + "?type=open_tvshow&tvshow=" + str(tvshow['tvshowid']) + "&season=" + str(tvshow['season'])
                    full_liz.append((path, liz, False))
                    count += 1
                    if count == 30:
                        break
            del json_query

    def parse_albums (self,request,list_type,full_liz):
        json_query = self._get_data(request)
        while json_query == "LOADING":
            xbmc.sleep( 100 )
            json_query = self._get_data(request)

        if json_query:
            json_query = simplejson.loads(json_query)
            if json_query.has_key('result') and json_query['result'].has_key('albums'):
                count = 0
                for item in json_query['result']['albums']:
                    liz = xbmcgui.ListItem(item['title'])
                    liz.setInfo( type="Music", infoLabels={ "Title": item['title'] })
                    liz.setInfo( type="Music", infoLabels={ "Artist": item['artist'][0] })
                    liz.setInfo( type="Music", infoLabels={ "Genre": " / ".join(item['genre']) })
                    liz.setInfo( type="Music", infoLabels={ "Year": item['year'] })
                    liz.setThumbnailImage(item['thumbnail'])
                    liz.setIconImage('DefaultAlbumCover.png')
                    liz.setProperty("fanart_image", item['fanart'])
                    liz.setProperty("dbid", str(item['albumid']))
                    liz.setProperty("Album_Description", item['description'])
                    # Path will call plugin again, with the album id
                    path = sys.argv[0] + "?type=open_album&album=" + str(item['albumid'])
                    full_liz.append((path, liz, False))
                    count += 1
                    if count == self.LIMIT:
                        break
            del json_query

    def _get_data(self,request):
        if request == "recentmovies":
            json_string = '{"jsonrpc": "2.0",  "id": 1, "method": "VideoLibrary.GetMovies", "params": {"properties": ["title","playcount", "year", "genre", "runtime", "file", "resume", "art","plot","mpaa"], "limits": {"end": %d},' % self.LIMIT
            json_query = xbmc.executeJSONRPC('%s "sort": {"order": "descending", "method": "dateadded"}, "filter": {"field": "playcount", "operator": "is", "value": "0"}}}' %json_string)
            json_query = unicode(json_query, 'utf-8', errors='ignore')
        elif request == "randommovies":
            json_string = '{"jsonrpc": "2.0",  "id": 1, "method": "VideoLibrary.GetMovies", "params": {"properties": ["title", "originaltitle", "playcount", "year", "genre", "runtime", "file", "lastplayed", "trailer", "resume", "art", "dateadded"], "limits": {"end": %d},' % self.LIMIT
            json_query = xbmc.executeJSONRPC('%s "sort": {"method": "random" } }}' %json_string)
            json_query = unicode(json_query, 'utf-8', errors='ignore')
        elif request == "recentepisodes":
            json_string = '{"jsonrpc": "2.0", "id": 1, "method": "VideoLibrary.GetEpisodes", "params": { "properties": ["title", "playcount", "season", "episode", "showtitle", "tvshowid", "art","file","plot"], "limits": {"end": 30},'
            json_query = xbmc.executeJSONRPC('%s "sort": {"order": "descending", "method": "dateadded"}, "filter": {"field": "playcount", "operator": "lessthan", "value": "1"}}}' %json_string)
            json_query = unicode(json_query, 'utf-8', errors='ignore')
        elif request == "randomepisodes":
            json_string = '{"jsonrpc": "2.0", "id": 1, "method": "VideoLibrary.GetEpisodes", "params": { "properties": ["title", "playcount", "season", "episode", "showtitle", "file", "resume", "tvshowid", "art", "firstaired", "runtime", "dateadded", "lastplayed"], "limits": {"end": 30},'
            json_query = xbmc.executeJSONRPC('%s "sort": {"method": "random" }}}' %json_string)
            json_query = unicode(json_query, 'utf-8', errors='ignore')
        elif request == "randomalbums":
            json_string = '{"jsonrpc": "2.0", "id": 1, "method": "AudioLibrary.GetAlbums", "params": {"properties": ["title", "artist", "genre", "year", "thumbnail", "fanart", "playcount","description"], "limits": {"end": %d},' %self.LIMIT
            json_query = xbmc.executeJSONRPC('%s "sort": {"method": "random"}}}' %json_string)
            json_query = unicode(json_query, 'utf-8', errors='ignore')
        elif request == "recentalbums":
            json_string = '{"jsonrpc": "2.0", "id": 1, "method": "AudioLibrary.GetAlbums", "params": {"properties": ["title", "artist", "genre", "year", "thumbnail", "fanart", "playcount","description"], "limits": {"end": %d},' %self.LIMIT
            json_query = xbmc.executeJSONRPC('%s "sort": {"order": "descending", "method": "dateadded" }}}' %json_string)
            json_query = unicode(json_query, 'utf-8', errors='ignore')
        elif request == "favouritealbums":
            json_string = '{"jsonrpc": "2.0", "id": 1, "method": "AudioLibrary.GetAlbums", "params": {"properties": ["title", "artist", "genre", "year", "thumbnail", "fanart", "playcount","description"], "limits": {"end": %d},' %self.LIMIT
            json_query = xbmc.executeJSONRPC('%s "sort": {"order": "descending", "method": "playcount" }}}' %json_string)
            json_query = unicode(json_query, 'utf-8', errors='ignore')
        return json_query

    def _parse_argv(self):
        try:
            params = dict(arg.split("=") for arg in sys.argv[2].split("&"))
        except:
            params = {}
        self.TYPE = params.get("?type","")
        self.ALBUM = params.get("album", "")
        self.TVSHOW = params.get("tvshow", "")
        self.SEASON = params.get("season", "")
        self.LIMIT = int(params.get("limit","10"))

Main()