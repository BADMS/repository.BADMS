This script is used by Kodi skins by theDeadMan and supplies random / recent items functionality for music and videos.

