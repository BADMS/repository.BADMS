Pellucid
===================

Pellucid is a skin for Kodi by theDeadMan

Built in support for:
- PVR
- Rom Collection Browser
- Artist slideshow
- Artwork downloader


