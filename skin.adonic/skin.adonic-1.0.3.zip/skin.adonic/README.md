<h1>adonic</h1>

*1.0.1
- New view for other
- Tweeks to usage
- New fill in animation
- New uses of colorbox
*1.0.0
- Initial release.